# Image_Captioning_in_Arabic
Image Captioning platform for education purposes, the platform will generate pedagogical description in Arabic form a given picture.
